#include <iostream>

#include "StringChild.hpp"

int main()
{
	StringChild str1("     ",5);
	
	return 0;
}