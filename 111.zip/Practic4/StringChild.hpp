#pragma once

#include "String.hpp"

class StringChild : public String
{
protected:

public:
    StringChild(char* str, int len) : String(str,len) { };

    StringChild(const String& str) : String(str) { };

    StringChild Trim()
    {
        int start = _length,end = 0;
        for(int i = 0;i < _length;i++)
            if(_ptr[i] != ' ')
            {
                start = i;
                break;
            }

        for(int i = _length - 1;i >= 0;i--)
            if(_ptr[i] != ' ')
            {
                end = i;
                break;
            }

        if(start >= end)
            return StringChild(nullptr,0);

        int len = end - start + 1;
        char *str = new char[len];
            
        for(int i = 0;i < len;i++)
            str[i] = _ptr[i + start];

        StringChild trimmed(str,len);

        delete[] str;

        return trimmed;
    }

    ~StringChild() { };

};