#pragma once

class String
{
protected:
    int _length;
    
    char* _ptr;
public:
    String(char* str,int len)
    {
        _length = len;

        _ptr = new char[len];
        
        for(int i = 0;i < len;i++)
            _ptr[i] = str[i];
    };

    String(const String& str)
    {
        _length = str._length;

        _ptr = new char[str._length];
        
        for(int i = 0;i < _length;i++)
            _ptr[i] = str._ptr[i];
    };

    ~String()
    {
        delete[] _ptr;
    };

	String operator =(String str)
	{
		_length = str._length;

        _ptr = new char[str._length];
        
        for(int i = 0;i < _length;i++)
            _ptr[i] = str._ptr[i];
		
		return *this;
	};

    String Append(char c)
    {

    };

};