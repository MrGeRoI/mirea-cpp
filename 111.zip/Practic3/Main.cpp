#include <iostream>

/*	Иерарихия:

	   A1

	B1 B2 B3

	  C1 C2
*/

class A1
{
protected:
	int a1;

public:
	A1()
	{
		a1 = 1;
	}

	virtual void Print()
	{
		std::cout << "A1" << std::endl;
	}

	virtual void Show()
	{
		std::cout << "\ta1 = " << a1 << std::endl;
	}
};

class B1 : virtual public A1
{
protected:
	int b1;

public:
	B1() : A1()
	{
		b1 = 2;
	}

	virtual void Print() override
	{
		std::cout << "B1" << std::endl;
	}

	virtual void Show() override
	{
		std::cout << "\ta1 = " << a1 << std::endl <<
			"\tb1 = " << b1 << std::endl;
	}
};

class B2 : virtual public A1
{
protected:
	int b2;

public:
	B2() : A1()
	{
		b2 = 3;
	}

	virtual void Print() override
	{
		std::cout << "B2" << std::endl;
	}

	virtual void Show() override
	{
		std::cout << "\ta1 = " << a1 << std::endl <<
			"\tb2 = " << b2 << std::endl;
	}
};

class B3 : virtual public A1
{
protected:
	int b3;

public:
	B3() : A1()
	{
		b3 = 4;
	}

	virtual void Print() override
	{
		std::cout << "B3" << std::endl;
	}

	virtual void Show() override
	{
		std::cout << "\ta1 = " << a1 << std::endl <<
			"\tb3 = " << b3 << std::endl;
	}
};

class C1 : virtual public B1 , virtual public B2 , virtual public B3
{
protected:
	int c1;

public:
	C1() : B1() , B2() , B3()
	{
		c1 = 5;
	}

	virtual void Print() override
	{
		std::cout << "C1" << std::endl;
	}

	virtual void Show() override
	{
		std::cout << "\ta1 = " << a1 << std::endl <<
			"\tb1 = " << b1 << std::endl <<
			"\tb2 = " << b2 << std::endl <<
			"\tb3 = " << b3 << std::endl <<
			"\tc1 = " << c1 << std::endl;
	}
};

class C2 : virtual public B1 , virtual public B2 , virtual public B3
{
protected:
	int c2;

public:
	C2() : B1() , B2() , B3()
	{
		c2 = 6;
	}

	virtual void Print() override
	{
		std::cout << "C2" << std::endl;
	}

	virtual void Show() override
	{
		std::cout << "\ta1 = " << a1 << std::endl <<
			"\tb1 = " << b1 << std::endl <<
			"\tb2 = " << b2 << std::endl <<
			"\tb3 = " << b3 << std::endl <<
			"\tc2 = " << c2 << std::endl;
	}
};

int main()
{
	A1 a1;

	a1.Print();
	a1.Show();

	B3 b3;

	b3.Print();
	b3.Show();

	C2 c2;

	c2.Print();
	c2.Show();

	return 0;
}